# 🪐 Heroku Manager Bot

Heroku Userbotni boshqarish uchun professional Telegram bot.

## ✨ Imkoniyatlar

- 👤 **Foydalanuvchi tizimi** — ro'yxatdan o'tish, profil
- ⚙️ **O'rnatish qo'llanmalari** — VPS, Docker, HikkaHost, JamHost
- 🔧 **Sozlash yordami** — API kredensiallari yordamida shaxsiy yordam
- 💎 **Obuna tizimi** — Free / Premium / VIP tariflar
- 💳 **To'lov tizimi** — karta/Payme/Click orqali to'lov
- 📚 **Qo'llanmalar** — buyruqlar, modullar, xavfsizlik
- 💬 **Support ticketlar** — murojaat yuborish va javob olish
- 👑 **Admin panel** — foydalanuvchilar, to'lovlar, broadcast

---

## 🚀 O'rnatish

### 1. Fayllarni yuklab oling
```bash
# Bot fayllarini serverga ko'chiring yoki git clone qiling
```

### 2. Kutubxonalarni o'rnating
```bash
pip install -r requirements.txt
```

### 3. Sozlamalarni kiriting
```bash
cp .env.example .env
nano .env
```

`.env` faylida quyidagilarni to'ldiring:
```
BOT_TOKEN=BotFather dan token
ADMIN_IDS=Siz ning Telegram ID
PAYMENT_CARD=Karta raqami
CARD_OWNER=Karta egasi ismi
PAYMENT_PHONE=+998XXXXXXXXX
```

### 4. Botni ishga tushiring
```bash
python3 bot.py
```

### 5. Fon rejimida ishlatish
```bash
screen -S heroku_bot
python3 bot.py
# CTRL+A, keyin D
```

---

## 📁 Fayl tuzilishi

```
heroku_manager_bot/
├── bot.py                  # Asosiy fayl
├── texts.py                # O'zbekcha matnlar
├── keyboards.py            # Tugmalar
├── requirements.txt        # Kutubxonalar
├── .env.example            # Sozlamalar namunasi
├── database/
│   └── db.py               # Ma'lumotlar bazasi
├── handlers/
│   ├── user.py             # Foydalanuvchi handlerlari
│   ├── setup.py            # Sozlash/Support handlerlari
│   ├── payment.py          # To'lov handlerlari
│   └── admin.py            # Admin handlerlari
└── middlewares/
    └── subscription.py     # Tekshirish middleware
```

---

## 👑 Admin Buyruqlari

| Buyruq | Tavsif |
|--------|--------|
| `/admin` | Admin panelni ochish |
| `/ban [id]` | Foydalanuvchini bloklash |
| `/unban [id]` | Blokdan chiqarish |
| `/promote [id]` | Admin qilish |

---

## 💳 Tariflar

| Tarif | Narx | Muddat |
|-------|------|--------|
| Free | Bepul | Cheksiz |
| Premium | 30,000 so'm | 1 oy |
| VIP | 75,000 so'm | 3 oy |

Narxlarni `handlers/payment.py` faylida `PLANS` o'zgaruvchisi orqali o'zgartirish mumkin.

---

## 🛠️ Texnologiyalar

- Python 3.9+
- aiogram 3.x
- aiosqlite (SQLite)
- python-dotenv

---

## 📞 Bog'lanish

Muammo yoki savol bo'lsa: bot ichidagi `/support` buyrug'idan foydalaning.
