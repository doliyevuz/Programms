"""
Foydalanuvchilarni tekshirish middleware
"""

import logging
from typing import Any, Awaitable, Callable, Dict
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery

from database.db import get_user, create_user
import texts

logger = logging.getLogger(__name__)


class SubscriptionMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: Dict[str, Any],
    ) -> Any:
        # Message yoki CallbackQuery dan user olish
        if isinstance(event, Message):
            user = event.from_user
            send = event.answer
        elif isinstance(event, CallbackQuery):
            user = event.from_user
            send = event.message.answer
        else:
            return await handler(event, data)

        if not user:
            return await handler(event, data)

        # Bot xabarlarini o'tkazib yuborish
        if user.is_bot:
            return await handler(event, data)

        # Foydalanuvchini DB da tekshirish / yaratish
        db_user = await get_user(user.id)
        if not db_user:
            await create_user(
                user.id,
                user.username or "",
                user.full_name or ""
            )
            db_user = await get_user(user.id)

        # Ban tekshirish
        if db_user and db_user['is_banned']:
            if isinstance(event, Message):
                await event.answer(texts.BANNED)
            elif isinstance(event, CallbackQuery):
                await event.answer(texts.BANNED, show_alert=True)
            return

        # Ma'lumotlarni context ga qo'shish
        data['db_user'] = db_user

        return await handler(event, data)
