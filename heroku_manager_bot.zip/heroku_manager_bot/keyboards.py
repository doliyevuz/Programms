"""
⌨️ Barcha tugmalar (Inline va Reply keyboard)
"""

from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder


# ========== ASOSIY MENYU ==========
def main_menu_kb(is_admin: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="⚙️ O'rnatish", callback_data="install"),
        InlineKeyboardButton(text="🔧 Sozlash Yordami", callback_data="setup_help")
    )
    builder.row(
        InlineKeyboardButton(text="🖥️ Serverim", callback_data="ssh_panel"),
        InlineKeyboardButton(text="📚 Qo'llanma", callback_data="guide"),
    )
    builder.row(
        InlineKeyboardButton(text="💎 Obuna", callback_data="subscription"),
        InlineKeyboardButton(text="💬 Yordam", callback_data="support"),
    )
    builder.row(
        InlineKeyboardButton(text="👤 Profilim", callback_data="profile")
    )
    if is_admin:
        builder.row(
            InlineKeyboardButton(text="👑 Admin Panel", callback_data="admin_panel")
        )
    return builder.as_markup()


# ========== O'RNATISH ==========
def install_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🖥️ VPS/VDS", callback_data="install_vps"),
        InlineKeyboardButton(text="🐳 Docker", callback_data="install_docker")
    )
    builder.row(
        InlineKeyboardButton(text="🌐 HikkaHost/JamHost", callback_data="install_hikkahost")
    )
    builder.row(
        InlineKeyboardButton(text="🔑 API Kredensiallari", callback_data="install_api")
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu")
    )
    return builder.as_markup()


def install_back_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="⚙️ Sozlash Yordami So'rash", callback_data="setup_help")
    )
    builder.row(
        InlineKeyboardButton(text="🔙 O'rnatish menyusi", callback_data="install")
    )
    return builder.as_markup()


# ========== QOLLANMA ==========
def guide_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📋 Buyruqlar", callback_data="guide_commands"),
        InlineKeyboardButton(text="🧩 Modullar", callback_data="guide_modules")
    )
    builder.row(
        InlineKeyboardButton(text="🔒 Xavfsizlik", callback_data="guide_security"),
        InlineKeyboardButton(text="🔧 Muammolar", callback_data="guide_troubleshoot")
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu")
    )
    return builder.as_markup()


def guide_back_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🔙 Qo'llanmalar", callback_data="guide")
    )
    return builder.as_markup()


# ========== SOZLASH ==========
def setup_server_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🖥️ VPS/VDS", callback_data="setup_server_vps"),
        InlineKeyboardButton(text="🐳 Docker", callback_data="setup_server_docker")
    )
    builder.row(
        InlineKeyboardButton(text="🌐 HikkaHost", callback_data="setup_server_hikkahost"),
        InlineKeyboardButton(text="🌐 JamHost", callback_data="setup_server_jamhost")
    )
    builder.row(
        InlineKeyboardButton(text="❌ Bekor qilish", callback_data="main_menu")
    )
    return builder.as_markup()


def setup_confirm_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Yuborish", callback_data="setup_confirm"),
        InlineKeyboardButton(text="❌ Bekor qilish", callback_data="main_menu")
    )
    return builder.as_markup()


# ========== OBUNA ==========
def subscription_menu_kb(has_subscription: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if not has_subscription:
        builder.row(
            InlineKeyboardButton(text="💫 Premium — 30,000 so'm", callback_data="pay_premium")
        )
        builder.row(
            InlineKeyboardButton(text="👑 VIP — 75,000 so'm", callback_data="pay_vip")
        )
    else:
        builder.row(
            InlineKeyboardButton(text="🔄 Yangilash", callback_data="pay_premium")
        )
    builder.row(
        InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu")
    )
    return builder.as_markup()


def payment_sent_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ To'lov yuborildim", callback_data="payment_sent")
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Orqaga", callback_data="subscription")
    )
    return builder.as_markup()


def back_to_main_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🏠 Asosiy menyu", callback_data="main_menu")
    )
    return builder.as_markup()


# ========== ADMIN PANEL ==========
def admin_panel_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📊 Statistika", callback_data="admin_stats"),
        InlineKeyboardButton(text="👥 Foydalanuvchilar", callback_data="admin_users")
    )
    builder.row(
        InlineKeyboardButton(text="💳 To'lovlar", callback_data="admin_payments"),
        InlineKeyboardButton(text="🎫 Ticketlar", callback_data="admin_tickets")
    )
    builder.row(
        InlineKeyboardButton(text="📢 Xabar yuborish", callback_data="admin_broadcast")
    )
    builder.row(
        InlineKeyboardButton(text="🔙 Asosiy menyu", callback_data="main_menu")
    )
    return builder.as_markup()


def admin_payment_kb(payment_id: int, user_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Tasdiqlash",
            callback_data=f"admin_pay_approve_{payment_id}_{user_id}"
        ),
        InlineKeyboardButton(
            text="❌ Rad etish",
            callback_data=f"admin_pay_reject_{payment_id}_{user_id}"
        )
    )
    return builder.as_markup()


def admin_ticket_kb(ticket_id: int, user_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="💬 Javob berish",
            callback_data=f"admin_ticket_reply_{ticket_id}_{user_id}"
        )
    )
    return builder.as_markup()


def admin_broadcast_confirm_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Yuborish", callback_data="admin_broadcast_send"),
        InlineKeyboardButton(text="❌ Bekor", callback_data="admin_panel")
    )
    return builder.as_markup()


def admin_back_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🔙 Admin Panel", callback_data="admin_panel")
    )
    return builder.as_markup()


def remove_keyboard() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()
