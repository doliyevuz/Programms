"""
⚙️ Heroku Sozlash Yordami handlerlari (FSM)
"""

import logging
import os
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database.db import create_installation, update_installation, get_user
import texts
import keyboards as kb

router = Router()
logger = logging.getLogger(__name__)

ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]


class SetupStates(StatesGroup):
    waiting_api_id = State()
    waiting_api_hash = State()
    waiting_server = State()
    confirming = State()


class SupportStates(StatesGroup):
    waiting_message = State()


# ========== SOZLASH ==========

@router.callback_query(F.data == "setup_help")
async def cb_setup_help(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.edit_text(
        texts.SETUP_REQUEST_API,
        reply_markup=None
    )
    await state.set_state(SetupStates.waiting_api_id)
    await call.answer()


@router.message(SetupStates.waiting_api_id)
async def process_api_id(message: Message, state: FSMContext):
    api_id = message.text.strip()
    if not api_id.isdigit():
        await message.answer("❌ API ID faqat raqamlardan iborat bo'lishi kerak. Qayta kiriting:")
        return

    await state.update_data(api_id=api_id)
    await message.answer(texts.SETUP_REQUEST_HASH)
    await state.set_state(SetupStates.waiting_api_hash)


@router.message(SetupStates.waiting_api_hash)
async def process_api_hash(message: Message, state: FSMContext):
    api_hash = message.text.strip()
    if len(api_hash) != 32:
        await message.answer("❌ API Hash 32 belgidan iborat bo'lishi kerak. Qayta kiriting:")
        return

    await state.update_data(api_hash=api_hash)
    await message.answer(
        texts.SETUP_REQUEST_SERVER,
        reply_markup=kb.setup_server_kb()
    )
    await state.set_state(SetupStates.waiting_server)


@router.callback_query(F.data.startswith("setup_server_"), SetupStates.waiting_server)
async def process_server_type(call: CallbackQuery, state: FSMContext, bot: Bot):
    server_map = {
        "setup_server_vps": "VPS/VDS",
        "setup_server_docker": "Docker",
        "setup_server_hikkahost": "HikkaHost",
        "setup_server_jamhost": "JamHost",
    }
    server_type = server_map.get(call.data, "Noma'lum")
    await state.update_data(server_type=server_type)

    data = await state.get_data()
    confirm_text = f"""
✅ <b>So'rov ma'lumotlari:</b>

🔑 <b>API ID:</b> <code>{data['api_id']}</code>
🔐 <b>API Hash:</b> <code>{data['api_hash'][:8]}...{data['api_hash'][-4:]}</code>
🖥️ <b>Server:</b> {server_type}

Yuborishni tasdiqlaysizmi?
"""
    await call.message.edit_text(confirm_text, reply_markup=kb.setup_confirm_kb())
    await state.set_state(SetupStates.confirming)
    await call.answer()


@router.callback_query(F.data == "setup_confirm", SetupStates.confirming)
async def process_setup_confirm(call: CallbackQuery, state: FSMContext, bot: Bot):
    data = await state.get_data()
    user_id = call.from_user.id
    user = await get_user(user_id)

    # DB ga saqlash
    install_id = await create_installation(user_id, data['server_type'])
    await update_installation(
        install_id,
        api_id=data['api_id'],
        api_hash=data['api_hash'],
        status='pending'
    )

    # Foydalanuvchiga xabar
    await call.message.edit_text(
        texts.SETUP_SAVED,
        reply_markup=kb.back_to_main_kb()
    )

    # Adminlarga xabar yuborish
    username = call.from_user.username or "yo'q"
    name = call.from_user.full_name
    admin_text = texts.ADMIN_NEW_SETUP.format(
        name=name,
        username=username,
        user_id=user_id,
        server_type=data['server_type']
    )

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="💬 Javob yozish",
            url=f"tg://user?id={user_id}"
        )
    )

    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, admin_text, reply_markup=builder.as_markup())
        except Exception as e:
            logger.error(f"Admin ga xabar yuborishda xato: {e}")

    await state.clear()
    await call.answer()


# ========== SUPPORT ==========

@router.callback_query(F.data == "support")
async def cb_support(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.edit_text(texts.SUPPORT_MENU)
    await state.set_state(SupportStates.waiting_message)
    await call.answer()


@router.message(SupportStates.waiting_message)
async def process_support_message(message: Message, state: FSMContext, bot: Bot):
    from database.db import create_ticket
    user_id = message.from_user.id
    user = await get_user(user_id)

    ticket_id = await create_ticket(user_id, message.text)

    await message.answer(
        texts.TICKET_CREATED.format(ticket_id=ticket_id),
        reply_markup=kb.back_to_main_kb()
    )

    # Adminlarga xabar
    username = message.from_user.username or "yo'q"
    name = message.from_user.full_name
    admin_text = texts.ADMIN_NEW_TICKET.format(
        name=name,
        username=username,
        user_id=user_id,
        ticket_id=ticket_id,
        message=message.text
    )

    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                admin_text,
                reply_markup=kb.admin_ticket_kb(ticket_id, user_id)
            )
        except Exception as e:
            logger.error(f"Admin ga ticket xabari yuborishda xato: {e}")

    await state.clear()
