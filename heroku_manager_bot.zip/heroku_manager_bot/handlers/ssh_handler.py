"""
🖥️ SSH Handler — Server ulanish va Heroku Userbot boshqarish
"""

import logging
import os
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardButton

from ssh_manager import (
    SSHManager, HerokuSSHController,
    save_ssh_creds, get_ssh_creds, delete_ssh_creds,
    get_ssh_controller, init_ssh_db
)

router = Router()
logger = logging.getLogger(__name__)

ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]


# ===== FSM STATES =====

class SSHSetupStates(StatesGroup):
    host = State()
    port = State()
    username = State()
    password = State()
    screen_name = State()
    heroku_path = State()


class CustomCmdState(StatesGroup):
    waiting = State()


# ===== KLAVIATURA =====

def server_menu_kb(has_creds: bool = False) -> InlineKeyboardBuilder:
    builder = InlineKeyboardBuilder()
    if has_creds:
        builder.row(
            InlineKeyboardButton(text="📊 Server holati", callback_data="ssh_status"),
            InlineKeyboardButton(text="📋 Loglar", callback_data="ssh_logs"),
        )
        builder.row(
            InlineKeyboardButton(text="▶️ Ishga tushir", callback_data="ssh_start"),
            InlineKeyboardButton(text="⏹️ To'xtat", callback_data="ssh_stop"),
        )
        builder.row(
            InlineKeyboardButton(text="🔄 Restart", callback_data="ssh_restart"),
            InlineKeyboardButton(text="⬆️ Yangilash", callback_data="ssh_update"),
        )
        builder.row(
            InlineKeyboardButton(text="🖥️ Server info", callback_data="ssh_sysinfo"),
            InlineKeyboardButton(text="💻 Buyruq", callback_data="ssh_custom_cmd"),
        )
        builder.row(
            InlineKeyboardButton(text="🔑 Ulanishni o'zgartirish", callback_data="ssh_setup"),
            InlineKeyboardButton(text="🗑️ O'chirish", callback_data="ssh_delete"),
        )
    else:
        builder.row(
            InlineKeyboardButton(text="🔗 Serverga ulanish", callback_data="ssh_setup")
        )
    builder.row(
        InlineKeyboardButton(text="🔙 Asosiy menyu", callback_data="main_menu")
    )
    return builder.as_markup()


def confirm_kb(action: str) -> InlineKeyboardBuilder:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Ha, bajarish", callback_data=f"ssh_confirm_{action}"),
        InlineKeyboardButton(text="❌ Bekor", callback_data="ssh_panel"),
    )
    return builder.as_markup()


def back_kb() -> InlineKeyboardBuilder:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🔙 Server panel", callback_data="ssh_panel")
    )
    return builder.as_markup()


# ===== ASOSIY PANEL =====

@router.message(Command("server"))
async def cmd_server(message: Message):
    creds = await get_ssh_creds(message.from_user.id)
    await message.answer(
        "🖥️ <b>Server Boshqaruv Paneli</b>\n\n"
        + ("✅ Server ulanish sozlangan." if creds
           else "❌ Hali server ulanmagan.\nUlanish uchun quyidagi tugmani bosing."),
        reply_markup=server_menu_kb(has_creds=bool(creds))
    )


@router.callback_query(F.data == "ssh_panel")
async def cb_ssh_panel(call: CallbackQuery, state: FSMContext):
    await state.clear()
    creds = await get_ssh_creds(call.from_user.id)
    await call.message.edit_text(
        "🖥️ <b>Server Boshqaruv Paneli</b>\n\n"
        + ("✅ Server ulanish sozlangan." if creds
           else "❌ Hali server ulanmagan."),
        reply_markup=server_menu_kb(has_creds=bool(creds))
    )
    await call.answer()


# ===== SSH ULANISHNI SOZLASH (FSM) =====

@router.callback_query(F.data == "ssh_setup")
async def cb_ssh_setup(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.edit_text(
        "🔐 <b>Server SSH Ulanishini Sozlash</b>\n\n"
        "<b>1/6 — Server IP manzilini kiriting:</b>\n"
        "<i>Masalan: 192.168.1.100 yoki server.example.com</i>"
    )
    await state.set_state(SSHSetupStates.host)
    await call.answer()


@router.message(SSHSetupStates.host)
async def process_ssh_host(message: Message, state: FSMContext):
    host = message.text.strip()
    if len(host) < 4 or " " in host:
        await message.answer("❌ Noto'g'ri IP/domen. Qayta kiriting:")
        return
    await state.update_data(host=host)
    await message.answer(
        "✅ Host qabul qilindi.\n\n"
        "<b>2/6 — SSH Port raqami:</b>\n"
        "<i>Standart: 22 (shunday bo'lsa 22 yozing)</i>"
    )
    await state.set_state(SSHSetupStates.port)


@router.message(SSHSetupStates.port)
async def process_ssh_port(message: Message, state: FSMContext):
    port_str = message.text.strip()
    if not port_str.isdigit() or not (1 <= int(port_str) <= 65535):
        await message.answer("❌ Port 1-65535 orasida bo'lishi kerak. Qayta kiriting:")
        return
    await state.update_data(port=int(port_str))
    await message.answer(
        "✅ Port qabul qilindi.\n\n"
        "<b>3/6 — SSH Foydalanuvchi nomi:</b>\n"
        "<i>Ko'pincha: root yoki ubuntu</i>"
    )
    await state.set_state(SSHSetupStates.username)


@router.message(SSHSetupStates.username)
async def process_ssh_username(message: Message, state: FSMContext):
    await state.update_data(username=message.text.strip())
    await message.answer(
        "✅ Foydalanuvchi nomi qabul qilindi.\n\n"
        "<b>4/6 — SSH Parol:</b>\n"
        "<i>⚠️ Xabar yuborilgandan so'ng bot uni xavfsiz saqlaydi.</i>\n"
        "<i>Agar SSH key ishlatmoqchi bo'lsangiz — bu qismni o'tkazib yuboring: /skip yozing</i>"
    )
    await state.set_state(SSHSetupStates.password)


@router.message(SSHSetupStates.password)
async def process_ssh_password(message: Message, state: FSMContext):
    password = None if message.text.strip() == "/skip" else message.text.strip()

    # Xavfsizlik uchun xabarni o'chirish
    try:
        await message.delete()
    except Exception:
        pass

    await state.update_data(password=password)
    await message.answer(
        "✅ Parol qabul qilindi.\n\n"
        "<b>5/6 — Screen sessiya nomi:</b>\n"
        "<i>Standart: heroku (shunday bo'lsa heroku yozing)</i>"
    )
    await state.set_state(SSHSetupStates.screen_name)


@router.message(SSHSetupStates.screen_name)
async def process_screen_name(message: Message, state: FSMContext):
    await state.update_data(screen_name=message.text.strip())
    await message.answer(
        "✅ Screen nomi qabul qilindi.\n\n"
        "<b>6/6 — Heroku Userbot papkasi yo'li:</b>\n"
        "<i>Standart: ~/Heroku (shunday bo'lsa ~/Heroku yozing)</i>"
    )
    await state.set_state(SSHSetupStates.heroku_path)


@router.message(SSHSetupStates.heroku_path)
async def process_heroku_path(message: Message, state: FSMContext):
    heroku_path = message.text.strip()
    await state.update_data(heroku_path=heroku_path)
    data = await state.get_data()

    # Ulanishni sinab ko'rish
    checking_msg = await message.answer("🔄 Server bilan ulanish sinab ko'rilmoqda...")

    try:
        ssh = SSHManager(
            host=data['host'],
            port=data['port'],
            username=data['username'],
            password=data.get('password'),
        )
        async with ssh:
            out, _, _ = await ssh.run("echo 'OK'")
            if "OK" not in out:
                raise Exception("Server javob bermadi")

        # Ma'lumotlarni saqlash
        await save_ssh_creds(
            user_id=message.from_user.id,
            host=data['host'],
            port=data['port'],
            username=data['username'],
            password=data.get('password'),
            screen_name=data['screen_name'],
            heroku_path=data['heroku_path'],
        )

        await checking_msg.edit_text(
            "✅ <b>Server muvaffaqiyatli ulandi!</b>\n\n"
            f"🌐 <b>Host:</b> <code>{data['host']}</code>\n"
            f"🔌 <b>Port:</b> {data['port']}\n"
            f"👤 <b>User:</b> {data['username']}\n"
            f"📁 <b>Heroku path:</b> {data['heroku_path']}\n"
            f"🖥️ <b>Screen:</b> {data['screen_name']}",
            reply_markup=server_menu_kb(has_creds=True)
        )
    except Exception as e:
        await checking_msg.edit_text(
            f"❌ <b>Ulanishda xato:</b>\n<code>{str(e)}</code>\n\n"
            "Ma'lumotlarni tekshirib qayta urinib ko'ring.",
            reply_markup=back_kb()
        )

    await state.clear()


# ===== SERVER HOLATI =====

@router.callback_query(F.data == "ssh_status")
async def cb_ssh_status(call: CallbackQuery):
    ctrl = await get_ssh_controller(call.from_user.id)
    if not ctrl:
        await call.answer("❌ Avval serverga ulaning!", show_alert=True)
        return

    await call.message.edit_text("⏳ Server holati tekshirilmoqda...")

    try:
        async with ctrl.ssh:
            status = await ctrl.get_status()

        alive = "🟢 Ishlayapti" if status['is_alive'] else "🔴 To'xtagan"
        screen = "✅" if status['screen_running'] else "❌"
        proc = "✅" if status['process_running'] else "❌"

        text = (
            f"📊 <b>Heroku Userbot Holati</b>\n\n"
            f"🔵 <b>Umumiy holat:</b> {alive}\n"
            f"🖥️ <b>Screen sessiya:</b> {screen}\n"
            f"⚙️ <b>Python jarayon:</b> {proc}\n\n"
            f"📈 <b>Resurslar:</b>\n"
            f"   CPU: {status['cpu']}%\n"
            f"   RAM: {status['ram']}%\n"
            f"   Disk bo'sh: {status['disk_free']}\n"
            f"⏱️ <b>Uptime:</b> {status['uptime']}"
        )
        await call.message.edit_text(text, reply_markup=server_menu_kb(has_creds=True))
    except Exception as e:
        await call.message.edit_text(
            f"❌ <b>Ulanishda xato:</b>\n<code>{str(e)}</code>",
            reply_markup=server_menu_kb(has_creds=True)
        )
    await call.answer()


# ===== LOGLAR =====

@router.callback_query(F.data == "ssh_logs")
async def cb_ssh_logs(call: CallbackQuery):
    ctrl = await get_ssh_controller(call.from_user.id)
    if not ctrl:
        await call.answer("❌ Avval serverga ulaning!", show_alert=True)
        return

    await call.message.edit_text("⏳ Loglar yuklanmoqda...")

    try:
        async with ctrl.ssh:
            logs = await ctrl.get_logs(lines=40)

        if len(logs) > 3500:
            logs = "..." + logs[-3500:]

        await call.message.edit_text(
            f"📋 <b>Heroku Userbot Loglari</b>\n\n<pre>{logs}</pre>",
            reply_markup=back_kb()
        )
    except Exception as e:
        await call.message.edit_text(
            f"❌ Loglarni olishda xato:\n<code>{str(e)}</code>",
            reply_markup=back_kb()
        )
    await call.answer()


# ===== ISHGA TUSHIRISH =====

@router.callback_query(F.data == "ssh_start")
async def cb_ssh_start(call: CallbackQuery):
    ctrl = await get_ssh_controller(call.from_user.id)
    if not ctrl:
        await call.answer("❌ Avval serverga ulaning!", show_alert=True)
        return

    await call.message.edit_text("⏳ Heroku userbot ishga tushirilmoqda...")
    try:
        async with ctrl.ssh:
            success, msg = await ctrl.start()
        await call.message.edit_text(msg, reply_markup=server_menu_kb(has_creds=True))
    except Exception as e:
        await call.message.edit_text(
            f"❌ Xato: <code>{str(e)}</code>",
            reply_markup=server_menu_kb(has_creds=True)
        )
    await call.answer()


# ===== TO'XTATISH =====

@router.callback_query(F.data == "ssh_stop")
async def cb_ssh_stop(call: CallbackQuery):
    await call.message.edit_text(
        "⚠️ <b>Heroku userbotni to'xtatmoqchimisiz?</b>\n"
        "Userbot Telegram da ishlashni to'xtatadi.",
        reply_markup=confirm_kb("stop")
    )
    await call.answer()


@router.callback_query(F.data == "ssh_confirm_stop")
async def cb_confirm_stop(call: CallbackQuery):
    ctrl = await get_ssh_controller(call.from_user.id)
    if not ctrl:
        await call.answer("❌ Avval serverga ulaning!", show_alert=True)
        return

    await call.message.edit_text("⏳ To'xtatilmoqda...")
    try:
        async with ctrl.ssh:
            success, msg = await ctrl.stop()
        await call.message.edit_text(msg, reply_markup=server_menu_kb(has_creds=True))
    except Exception as e:
        await call.message.edit_text(
            f"❌ Xato: <code>{str(e)}</code>",
            reply_markup=server_menu_kb(has_creds=True)
        )
    await call.answer()


# ===== RESTART =====

@router.callback_query(F.data == "ssh_restart")
async def cb_ssh_restart(call: CallbackQuery):
    await call.message.edit_text(
        "🔄 <b>Heroku userbotni qayta ishga tushirmoqchimisiz?</b>",
        reply_markup=confirm_kb("restart")
    )
    await call.answer()


@router.callback_query(F.data == "ssh_confirm_restart")
async def cb_confirm_restart(call: CallbackQuery):
    ctrl = await get_ssh_controller(call.from_user.id)
    if not ctrl:
        await call.answer("❌ Avval serverga ulaning!", show_alert=True)
        return

    await call.message.edit_text("⏳ Qayta ishga tushirilmoqda...")
    try:
        async with ctrl.ssh:
            success, msg = await ctrl.restart()
        await call.message.edit_text(msg, reply_markup=server_menu_kb(has_creds=True))
    except Exception as e:
        await call.message.edit_text(
            f"❌ Xato: <code>{str(e)}</code>",
            reply_markup=server_menu_kb(has_creds=True)
        )
    await call.answer()


# ===== YANGILASH =====

@router.callback_query(F.data == "ssh_update")
async def cb_ssh_update(call: CallbackQuery):
    await call.message.edit_text(
        "⬆️ <b>GitHub dan yangi versiyani yuklab olmoqchimisiz?</b>\n"
        "<i>Heroku userbot to'xtatilmaydi, faqat fayllar yangilanadi.</i>",
        reply_markup=confirm_kb("update")
    )
    await call.answer()


@router.callback_query(F.data == "ssh_confirm_update")
async def cb_confirm_update(call: CallbackQuery):
    ctrl = await get_ssh_controller(call.from_user.id)
    if not ctrl:
        await call.answer("❌ Avval serverga ulaning!", show_alert=True)
        return

    await call.message.edit_text("⏳ Yangilanmoqda (GitHub dan yuklanmoqda)...")
    try:
        async with ctrl.ssh:
            success, msg = await ctrl.update()
        await call.message.edit_text(msg, reply_markup=server_menu_kb(has_creds=True))
    except Exception as e:
        await call.message.edit_text(
            f"❌ Xato: <code>{str(e)}</code>",
            reply_markup=server_menu_kb(has_creds=True)
        )
    await call.answer()


# ===== SERVER INFO =====

@router.callback_query(F.data == "ssh_sysinfo")
async def cb_ssh_sysinfo(call: CallbackQuery):
    ctrl = await get_ssh_controller(call.from_user.id)
    if not ctrl:
        await call.answer("❌ Avval serverga ulaning!", show_alert=True)
        return

    await call.message.edit_text("⏳ Server ma'lumotlari yuklanmoqda...")
    try:
        async with ctrl.ssh:
            info = await ctrl.get_system_info()
        await call.message.edit_text(info, reply_markup=back_kb())
    except Exception as e:
        await call.message.edit_text(
            f"❌ Xato: <code>{str(e)}</code>",
            reply_markup=back_kb()
        )
    await call.answer()


# ===== MAXSUS BUYRUQ (faqat admin) =====

@router.callback_query(F.data == "ssh_custom_cmd")
async def cb_ssh_custom_cmd(call: CallbackQuery, state: FSMContext):
    user_id = call.from_user.id
    creds = await get_ssh_creds(user_id)
    if not creds:
        await call.answer("❌ Avval serverga ulaning!", show_alert=True)
        return

    await call.message.edit_text(
        "💻 <b>Server Buyruq Bajarish</b>\n\n"
        "Serverda bajarilishi kerak bo'lgan buyruqni yozing:\n\n"
        "<i>Masalan:</i>\n"
        "<code>ls ~/Heroku</code>\n"
        "<code>cat ~/Heroku/heroku.log | tail -20</code>\n"
        "<code>pip list | grep telethon</code>\n\n"
        "⚠️ <i>Ehtiyot bo'ling — xavfli buyruqlar bloklangan.</i>"
    )
    await state.set_state(CustomCmdState.waiting)
    await call.answer()


@router.message(CustomCmdState.waiting)
async def process_custom_cmd(message: Message, state: FSMContext):
    ctrl = await get_ssh_controller(message.from_user.id)
    if not ctrl:
        await message.answer("❌ Server ulanishi topilmadi.")
        await state.clear()
        return

    processing = await message.answer(f"⏳ Bajarilmoqda: <code>{message.text}</code>")

    try:
        async with ctrl.ssh:
            result, success = await ctrl.run_custom_command(message.text)

        icon = "✅" if success else "⚠️"
        await processing.edit_text(
            f"{icon} <b>Natija:</b>\n<pre>{result}</pre>",
            reply_markup=back_kb()
        )
    except Exception as e:
        await processing.edit_text(
            f"❌ Xato: <code>{str(e)}</code>",
            reply_markup=back_kb()
        )

    await state.clear()


# ===== ULANISHNI O'CHIRISH =====

@router.callback_query(F.data == "ssh_delete")
async def cb_ssh_delete(call: CallbackQuery):
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Ha, o'chirish", callback_data="ssh_confirm_delete"),
        InlineKeyboardButton(text="❌ Bekor", callback_data="ssh_panel"),
    )
    await call.message.edit_text(
        "🗑️ <b>Server ulanishini o'chirishni xohlaysizmi?</b>\n"
        "<i>SSH kredensiallari o'chiriladi.</i>",
        reply_markup=builder.as_markup()
    )
    await call.answer()


@router.callback_query(F.data == "ssh_confirm_delete")
async def cb_confirm_delete(call: CallbackQuery):
    await delete_ssh_creds(call.from_user.id)
    await call.message.edit_text(
        "✅ Server ulanishi o'chirildi.",
        reply_markup=server_menu_kb(has_creds=False)
    )
    await call.answer()
