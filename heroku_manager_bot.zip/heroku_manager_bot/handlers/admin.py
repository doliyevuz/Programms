"""
👑 Admin Panel handlerlari
"""

import logging
import os
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database.db import (
    get_stats, get_all_users, get_pending_payments,
    get_open_tickets, reply_ticket, ban_user, set_admin
)
import texts
import keyboards as kb

router = Router()
logger = logging.getLogger(__name__)

ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


class AdminStates(StatesGroup):
    broadcast_message = State()
    broadcast_confirm = State()
    ticket_reply = State()


class AdminTicketReply(StatesGroup):
    waiting_reply = State()


# ========== ADMIN PANEL ==========

@router.message(Command("admin"))
async def cmd_admin(message: Message):
    if not is_admin(message.from_user.id):
        return
    await message.answer(texts.ADMIN_PANEL, reply_markup=kb.admin_panel_kb())


@router.callback_query(F.data == "admin_panel")
async def cb_admin_panel(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return
    await state.clear()
    await call.message.edit_text(texts.ADMIN_PANEL, reply_markup=kb.admin_panel_kb())
    await call.answer()


# ========== STATISTIKA ==========

@router.callback_query(F.data == "admin_stats")
async def cb_admin_stats(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    stats = await get_stats()
    text = texts.ADMIN_STATS.format(
        total_users=stats['total_users'],
        active_users=stats['active_users'],
        premium_users=stats['premium_users'],
        total_payments=stats['total_payments'],
        total_revenue=stats['total_revenue'],
        open_tickets=stats['open_tickets']
    )
    await call.message.edit_text(text, reply_markup=kb.admin_back_kb())
    await call.answer()


# ========== FOYDALANUVCHILAR ==========

@router.callback_query(F.data == "admin_users")
async def cb_admin_users(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    users = await get_all_users()
    if not users:
        await call.answer("Foydalanuvchilar yo'q", show_alert=True)
        return

    text = f"👥 <b>Foydalanuvchilar ro'yxati</b> ({len(users)} ta)\n\n"
    for u in users[:20]:  # Birinchi 20 ta
        status = "🚫" if u['is_banned'] else ("👑" if u['is_admin'] else "✅")
        username = f"@{u['username']}" if u['username'] else "username yo'q"
        text += f"{status} <code>{u['user_id']}</code> — {u['full_name']} ({username})\n"

    if len(users) > 20:
        text += f"\n... va yana {len(users) - 20} ta"

    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🔙 Admin Panel", callback_data="admin_panel")
    )
    await call.message.edit_text(text, reply_markup=builder.as_markup())
    await call.answer()


@router.message(Command("ban"))
async def cmd_ban(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("Ishlatish: /ban [user_id]")
        return
    try:
        target_id = int(args[1])
        await ban_user(target_id, True)
        await message.answer(texts.USER_BANNED)
        try:
            await bot.send_message(target_id, texts.BANNED)
        except:
            pass
    except ValueError:
        await message.answer("❌ Noto'g'ri ID format")


@router.message(Command("unban"))
async def cmd_unban(message: Message):
    if not is_admin(message.from_user.id):
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("Ishlatish: /unban [user_id]")
        return
    try:
        target_id = int(args[1])
        await ban_user(target_id, False)
        await message.answer(texts.USER_UNBANNED)
    except ValueError:
        await message.answer("❌ Noto'g'ri ID format")


@router.message(Command("promote"))
async def cmd_promote(message: Message):
    if not is_admin(message.from_user.id):
        return
    args = message.text.split()
    if len(args) < 2:
        await message.answer("Ishlatish: /promote [user_id]")
        return
    try:
        target_id = int(args[1])
        await set_admin(target_id, True)
        await message.answer(texts.USER_PROMOTED)
    except ValueError:
        await message.answer("❌ Noto'g'ri ID format")


# ========== TO'LOVLAR ==========

@router.callback_query(F.data == "admin_payments")
async def cb_admin_payments(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    payments = await get_pending_payments()
    if not payments:
        await call.answer("✅ Kutilayotgan to'lovlar yo'q", show_alert=True)
        return

    for p in payments:
        username = f"@{p['username']}" if p['username'] else "username yo'q"
        text = (
            f"💳 <b>To'lov #{p['id']}</b>\n"
            f"👤 {p['full_name']} ({username})\n"
            f"🆔 <code>{p['user_id']}</code>\n"
            f"📦 Tarif: {p['plan']}\n"
            f"💰 Summa: {p['amount']:,.0f} so'm\n"
            f"📅 Sana: {str(p['created_at'])[:16]}"
        )
        await call.message.answer(
            text,
            reply_markup=kb.admin_payment_kb(p['id'], p['user_id'])
        )

    await call.answer()


# ========== TICKETLAR ==========

@router.callback_query(F.data == "admin_tickets")
async def cb_admin_tickets(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    tickets = await get_open_tickets()
    if not tickets:
        await call.answer("✅ Ochiq ticketlar yo'q", show_alert=True)
        return

    for t in tickets:
        username = f"@{t['username']}" if t['username'] else "username yo'q"
        text = (
            f"🎫 <b>Ticket #{t['id']}</b>\n"
            f"👤 {t['full_name']} ({username})\n"
            f"🆔 <code>{t['user_id']}</code>\n"
            f"📅 {str(t['created_at'])[:16]}\n\n"
            f"📝 <b>Xabar:</b>\n{t['message']}"
        )
        await call.message.answer(
            text,
            reply_markup=kb.admin_ticket_kb(t['id'], t['user_id'])
        )

    await call.answer()


@router.callback_query(F.data.startswith("admin_ticket_reply_"))
async def cb_ticket_reply_start(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    parts = call.data.split("_")
    ticket_id = int(parts[3])
    user_id = int(parts[4])

    await state.update_data(ticket_id=ticket_id, user_id=user_id)
    await call.message.answer(
        f"💬 Ticket #{ticket_id} ga javobingizni yozing:"
    )
    await state.set_state(AdminTicketReply.waiting_reply)
    await call.answer()


@router.message(AdminTicketReply.waiting_reply)
async def process_ticket_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    ticket_id = data['ticket_id']
    user_id = data['user_id']

    await reply_ticket(ticket_id, message.text)

    # Foydalanuvchiga javob yuborish
    try:
        await bot.send_message(
            user_id,
            texts.TICKET_REPLY.format(reply=message.text),
            reply_markup=kb.back_to_main_kb()
        )
        await message.answer(f"✅ Ticket #{ticket_id} ga javob yuborildi!")
    except Exception as e:
        await message.answer(f"❌ Xabar yuborishda xato: {e}")

    await state.clear()


# ========== BROADCAST ==========

@router.callback_query(F.data == "admin_broadcast")
async def cb_admin_broadcast(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    await call.message.edit_text(texts.ADMIN_BROADCAST_REQUEST)
    await state.set_state(AdminStates.broadcast_message)
    await call.answer()


@router.message(AdminStates.broadcast_message)
async def process_broadcast_message(message: Message, state: FSMContext):
    await state.update_data(broadcast_text=message.text)
    await message.answer(
        texts.ADMIN_BROADCAST_CONFIRM.format(message=message.text),
        reply_markup=kb.admin_broadcast_confirm_kb()
    )
    await state.set_state(AdminStates.broadcast_confirm)


@router.callback_query(F.data == "admin_broadcast_send", AdminStates.broadcast_confirm)
async def process_broadcast_send(call: CallbackQuery, state: FSMContext, bot: Bot):
    if not is_admin(call.from_user.id):
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    data = await state.get_data()
    broadcast_text = data['broadcast_text']

    users = await get_all_users()
    sent = 0
    for user in users:
        if user['is_banned']:
            continue
        try:
            await bot.send_message(user['user_id'], broadcast_text)
            sent += 1
        except Exception:
            pass

    await call.message.edit_text(
        texts.ADMIN_BROADCAST_SENT.format(count=sent),
        reply_markup=kb.admin_back_kb()
    )
    await state.clear()
    await call.answer()
