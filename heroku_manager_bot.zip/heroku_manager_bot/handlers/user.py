"""
👤 Foydalanuvchi handlerlari
"""

import logging
import os
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart, Command

from database.db import get_user, get_subscription, is_premium
import texts
import keyboards as kb

router = Router()
logger = logging.getLogger(__name__)

ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]


@router.message(CommandStart())
async def cmd_start(message: Message, db_user=None):
    is_adm = message.from_user.id in ADMIN_IDS or (db_user and db_user['is_admin'])
    await message.answer(
        texts.WELCOME,
        reply_markup=kb.main_menu_kb(is_admin=is_adm)
    )


@router.message(Command("menu"))
async def cmd_menu(message: Message, db_user=None):
    is_adm = message.from_user.id in ADMIN_IDS or (db_user and db_user['is_admin'])
    await message.answer(
        texts.MAIN_MENU,
        reply_markup=kb.main_menu_kb(is_admin=is_adm)
    )


@router.callback_query(F.data == "main_menu")
async def cb_main_menu(call: CallbackQuery, db_user=None):
    is_adm = call.from_user.id in ADMIN_IDS or (db_user and db_user['is_admin'])
    await call.message.edit_text(
        texts.MAIN_MENU,
        reply_markup=kb.main_menu_kb(is_admin=is_adm)
    )
    await call.answer()


# ========== O'RNATISH ==========
@router.callback_query(F.data == "install")
async def cb_install(call: CallbackQuery):
    await call.message.edit_text(
        texts.INSTALL_INTRO,
        reply_markup=kb.install_menu_kb()
    )
    await call.answer()


@router.callback_query(F.data == "install_vps")
async def cb_install_vps(call: CallbackQuery):
    await call.message.edit_text(
        texts.INSTALL_VPS_GUIDE,
        reply_markup=kb.install_back_kb()
    )
    await call.answer()


@router.callback_query(F.data == "install_docker")
async def cb_install_docker(call: CallbackQuery):
    await call.message.edit_text(
        texts.INSTALL_DOCKER_GUIDE,
        reply_markup=kb.install_back_kb()
    )
    await call.answer()


@router.callback_query(F.data == "install_hikkahost")
async def cb_install_hikkahost(call: CallbackQuery):
    await call.message.edit_text(
        texts.INSTALL_HIKKAHOST_GUIDE,
        reply_markup=kb.install_back_kb()
    )
    await call.answer()


@router.callback_query(F.data == "install_api")
async def cb_install_api(call: CallbackQuery):
    await call.message.edit_text(
        texts.INSTALL_API_INFO,
        reply_markup=kb.install_back_kb()
    )
    await call.answer()


# ========== QOLLANMA ==========
@router.callback_query(F.data == "guide")
async def cb_guide(call: CallbackQuery):
    await call.message.edit_text(
        texts.GUIDE_MENU,
        reply_markup=kb.guide_menu_kb()
    )
    await call.answer()


@router.callback_query(F.data == "guide_commands")
async def cb_guide_commands(call: CallbackQuery):
    await call.message.edit_text(
        texts.GUIDE_COMMANDS,
        reply_markup=kb.guide_back_kb()
    )
    await call.answer()


@router.callback_query(F.data == "guide_modules")
async def cb_guide_modules(call: CallbackQuery):
    await call.message.edit_text(
        texts.GUIDE_MODULES,
        reply_markup=kb.guide_back_kb()
    )
    await call.answer()


@router.callback_query(F.data == "guide_security")
async def cb_guide_security(call: CallbackQuery):
    await call.message.edit_text(
        texts.GUIDE_SECURITY,
        reply_markup=kb.guide_back_kb()
    )
    await call.answer()


@router.callback_query(F.data == "guide_troubleshoot")
async def cb_guide_troubleshoot(call: CallbackQuery):
    await call.message.edit_text(
        texts.GUIDE_TROUBLESHOOT,
        reply_markup=kb.guide_back_kb()
    )
    await call.answer()


# ========== PROFIL ==========
@router.callback_query(F.data == "profile")
async def cb_profile(call: CallbackQuery, db_user=None):
    user_id = call.from_user.id
    sub = await get_subscription(user_id)
    premium = await is_premium(user_id)

    if sub and sub['plan'] != 'free' and sub['expires_at']:
        plan_text = f"💎 {sub['plan'].upper()}\n📅 Tugash: {sub['expires_at'][:10]}"
    elif premium:
        plan_text = "💎 Premium (Cheksiz)"
    else:
        plan_text = "🆓 Bepul"

    is_adm = call.from_user.id in ADMIN_IDS or (db_user and db_user['is_admin'])
    admin_badge = " 👑 Admin" if is_adm else ""

    text = f"""
👤 <b>Profilim</b>{admin_badge}

🆔 <b>ID:</b> <code>{user_id}</code>
👤 <b>Ism:</b> {call.from_user.full_name}
📦 <b>Obuna:</b> {plan_text}
"""
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="💎 Obuna olish", callback_data="subscription"))
    builder.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="main_menu"))

    await call.message.edit_text(text, reply_markup=builder.as_markup())
    await call.answer()
