"""
💳 To'lov handlerlari
"""

import logging
import os
from datetime import datetime, timedelta
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database.db import (
    get_subscription, create_payment, update_payment_status,
    create_or_update_subscription, is_premium, get_payment
)
import texts
import keyboards as kb

router = Router()
logger = logging.getLogger(__name__)

ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]

# To'lov ma'lumotlari (.env dan olish yoki default)
CARD_NUMBER = os.getenv("PAYMENT_CARD", "8600 0000 0000 0000")
CARD_OWNER = os.getenv("CARD_OWNER", "Ism Familiya")
PHONE = os.getenv("PAYMENT_PHONE", "+998901234567")

PLANS = {
    "premium": {"name": "💫 Premium (1 oy)", "amount": 30000, "days": 30},
    "vip": {"name": "👑 VIP (3 oy)", "amount": 75000, "days": 90},
}


class PaymentStates(StatesGroup):
    waiting_receipt = State()


@router.callback_query(F.data == "subscription")
async def cb_subscription(call: CallbackQuery):
    user_id = call.from_user.id
    premium = await is_premium(user_id)
    sub = await get_subscription(user_id)

    if premium and sub:
        plan_name = sub['plan'].upper()
        expires = sub['expires_at'][:10] if sub['expires_at'] else "Cheksiz"
        await call.message.edit_text(
            texts.SUBSCRIPTION_ACTIVE.format(plan=plan_name, expires=expires),
            reply_markup=kb.subscription_menu_kb(has_subscription=True)
        )
    else:
        await call.message.edit_text(
            texts.SUBSCRIPTION_INFO,
            reply_markup=kb.subscription_menu_kb(has_subscription=False)
        )
    await call.answer()


@router.callback_query(F.data.in_({"pay_premium", "pay_vip"}))
async def cb_select_plan(call: CallbackQuery, state: FSMContext):
    plan_key = "premium" if call.data == "pay_premium" else "vip"
    plan = PLANS[plan_key]
    user_id = call.from_user.id

    # Payment yaratish
    payment_row_id = await create_payment(user_id, plan['amount'], plan_key)

    # State ga saqlash
    await state.update_data(
        payment_row_id=payment_row_id,
        plan_key=plan_key,
        plan_name=plan['name']
    )

    instruction = texts.PAYMENT_INSTRUCTION.format(
        plan=plan['name'],
        amount=f"{plan['amount']:,}",
        card_number=CARD_NUMBER,
        card_owner=CARD_OWNER,
        phone=PHONE,
        user_id=user_id
    )

    await call.message.edit_text(
        instruction,
        reply_markup=kb.payment_sent_kb()
    )
    await call.answer()


@router.callback_query(F.data == "payment_sent")
async def cb_payment_sent(call: CallbackQuery, state: FSMContext, bot: Bot):
    data = await state.get_data()
    if not data.get('payment_row_id'):
        await call.answer("❌ Avval tarif rejasini tanlang!", show_alert=True)
        return

    payment_row_id = data['payment_row_id']
    plan_key = data['plan_key']
    plan_name = data['plan_name']
    plan = PLANS[plan_key]
    user_id = call.from_user.id

    await call.message.edit_text(
        texts.PAYMENT_SENT.format(payment_id=payment_row_id),
        reply_markup=kb.back_to_main_kb()
    )

    # Adminlarga xabar
    username = call.from_user.username or "yo'q"
    name = call.from_user.full_name
    admin_text = texts.ADMIN_PAYMENT_NOTIFY_ADMIN.format(
        name=name,
        username=username,
        user_id=user_id,
        plan=plan_name,
        amount=plan['amount'],
        payment_id=payment_row_id
    )

    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(
                admin_id,
                admin_text,
                reply_markup=kb.admin_payment_kb(payment_row_id, user_id)
            )
        except Exception as e:
            logger.error(f"Admin ga xabar yuborishda xato: {e}")

    await state.clear()
    await call.answer()


# ========== ADMIN: TO'LOV TASDIQLASH ==========

@router.callback_query(F.data.startswith("admin_pay_approve_"))
async def admin_approve_payment(call: CallbackQuery, bot: Bot):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    parts = call.data.split("_")
    payment_id = int(parts[3])
    user_id = int(parts[4])

    payment = await get_payment(payment_id)
    if not payment:
        await call.answer("❌ To'lov topilmadi!", show_alert=True)
        return

    plan_key = payment['plan']
    plan = PLANS.get(plan_key, PLANS['premium'])
    days = plan['days']

    expires = (datetime.now() + timedelta(days=days)).isoformat()
    await create_or_update_subscription(user_id, plan_key, expires)
    await update_payment_status(payment_id, 'approved')

    # Foydalanuvchiga xabar
    try:
        await bot.send_message(
            user_id,
            texts.PAYMENT_APPROVED.format(
                plan=plan['name'],
                expires=expires[:10]
            )
        )
    except Exception as e:
        logger.error(f"Foydalanuvchiga xabar yuborishda xato: {e}")

    await call.message.edit_text(
        call.message.text + "\n\n✅ <b>TASDIQLANDI</b>",
        reply_markup=None
    )
    await call.answer("✅ To'lov tasdiqlandi!")


@router.callback_query(F.data.startswith("admin_pay_reject_"))
async def admin_reject_payment(call: CallbackQuery, bot: Bot, state: FSMContext):
    if call.from_user.id not in ADMIN_IDS:
        await call.answer("❌ Ruxsat yo'q!", show_alert=True)
        return

    parts = call.data.split("_")
    payment_id = int(parts[3])
    user_id = int(parts[4])

    await update_payment_status(payment_id, 'rejected')

    # Foydalanuvchiga xabar
    try:
        await bot.send_message(
            user_id,
            texts.PAYMENT_REJECTED.format(reason="To'lov tasdiqlanmadi")
        )
    except Exception as e:
        logger.error(f"Foydalanuvchiga xabar yuborishda xato: {e}")

    await call.message.edit_text(
        call.message.text + "\n\n❌ <b>RAD ETILDI</b>",
        reply_markup=None
    )
    await call.answer("❌ To'lov rad etildi!")
