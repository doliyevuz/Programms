"""
🪐 Heroku Manager Bot
Foydalanuvchilar uchun Heroku Userbot boshqaruv tizimi
"""

import asyncio
import logging
import os
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from dotenv import load_dotenv

from handlers import admin, user, payment, setup
from handlers import ssh_handler
from middlewares.subscription import SubscriptionMiddleware
from database.db import init_db
from ssh_manager import init_ssh_db

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


async def main():
    BOT_TOKEN = os.getenv("BOT_TOKEN")
    if not BOT_TOKEN:
        raise ValueError("BOT_TOKEN topilmadi! .env faylini tekshiring.")

    await init_db()
    await init_ssh_db()

    bot = Bot(token=BOT_TOKEN, parse_mode="HTML")
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)

    # Middlewares
    dp.message.middleware(SubscriptionMiddleware())
    dp.callback_query.middleware(SubscriptionMiddleware())

    # Routers
    dp.include_router(admin.router)
    dp.include_router(payment.router)
    dp.include_router(setup.router)
    dp.include_router(ssh_handler.router)
    dp.include_router(user.router)

    logger.info("🪐 Heroku Manager Bot ishga tushmoqda...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
