"""
🔐 SSH orqali VPS serverga ulanish va Heroku Userbotni boshqarish
"""

import asyncio
import logging
import os
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

try:
    import asyncssh
    SSH_AVAILABLE = True
except ImportError:
    SSH_AVAILABLE = False
    logger.warning("asyncssh o'rnatilmagan! pip install asyncssh")


class SSHManager:
    """
    VPS serverga SSH orqali ulanib, Heroku Userbotni boshqaradi.
    Har bir foydalanuvchi o'z server ma'lumotlarini kiritadi.
    """

    def __init__(self, host: str, port: int, username: str,
                 password: str = None, key_path: str = None):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.key_path = key_path
        self._conn = None

    async def connect(self) -> bool:
        """Serverga ulanish"""
        if not SSH_AVAILABLE:
            raise RuntimeError("asyncssh o'rnatilmagan!")
        try:
            kwargs = {
                "host": self.host,
                "port": self.port,
                "username": self.username,
                "known_hosts": None,  # Production da bu o'zgartirilsin
                "connect_timeout": 15,
            }
            if self.password:
                kwargs["password"] = self.password
            elif self.key_path:
                kwargs["client_keys"] = [self.key_path]

            self._conn = await asyncssh.connect(**kwargs)
            logger.info(f"✅ SSH ulanish muvaffaqiyatli: {self.host}")
            return True
        except Exception as e:
            logger.error(f"❌ SSH ulanishda xato {self.host}: {e}")
            raise

    async def disconnect(self):
        """Ulanishni yopish"""
        if self._conn:
            self._conn.close()
            self._conn = None

    async def run(self, command: str, timeout: int = 30) -> Tuple[str, str, int]:
        """
        Buyruq bajarish.
        Returns: (stdout, stderr, exit_code)
        """
        if not self._conn:
            await self.connect()
        try:
            result = await asyncio.wait_for(
                self._conn.run(command, check=False),
                timeout=timeout
            )
            return result.stdout or "", result.stderr or "", result.exit_status
        except asyncio.TimeoutError:
            return "", f"Timeout ({timeout}s)", -1
        except Exception as e:
            return "", str(e), -1

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, *args):
        await self.disconnect()


class HerokuSSHController:
    """
    Heroku Userbot jarayonini SSH orqali boshqaradi.
    """

    def __init__(self, ssh: SSHManager, screen_name: str = "heroku",
                 heroku_path: str = "~/Heroku"):
        self.ssh = ssh
        self.screen_name = screen_name
        self.heroku_path = heroku_path

    async def get_status(self) -> dict:
        """Heroku userbot holati"""
        # Screen sessiya bormi?
        out, err, code = await self.ssh.run(
            f"screen -list | grep {self.screen_name}"
        )
        screen_running = code == 0 and self.screen_name in out

        # Python jarayoni bormi?
        out2, _, _ = await self.ssh.run(
            "ps aux | grep 'heroku' | grep -v grep | grep -v screen"
        )
        process_running = bool(out2.strip())

        # RAM va CPU
        out3, _, _ = await self.ssh.run(
            "ps aux | grep -E 'python.*heroku' | grep -v grep | "
            "awk '{print $3, $4}' | head -1"
        )
        cpu_ram = out3.strip().split() if out3.strip() else ["0", "0"]

        # Disk
        out4, _, _ = await self.ssh.run("df -h / | tail -1 | awk '{print $4}'")

        # Uptime
        out5, _, _ = await self.ssh.run("uptime -p")

        return {
            "screen_running": screen_running,
            "process_running": process_running,
            "cpu": cpu_ram[0] if len(cpu_ram) > 0 else "0",
            "ram": cpu_ram[1] if len(cpu_ram) > 1 else "0",
            "disk_free": out4.strip(),
            "uptime": out5.strip(),
            "is_alive": screen_running or process_running,
        }

    async def start(self) -> Tuple[bool, str]:
        """Heroku userbotni ishga tushirish"""
        # Avval screen bormi tekshir
        out, _, _ = await self.ssh.run(
            f"screen -list | grep {self.screen_name}"
        )
        if self.screen_name in out:
            return False, "Userbot allaqachon ishlamoqda!"

        cmd = (
            f"cd {self.heroku_path} && "
            f"screen -dmS {self.screen_name} "
            f"bash -c 'python3 -m heroku --root 2>&1 | tee -a heroku.log'"
        )
        _, err, code = await self.ssh.run(cmd)
        if code == 0:
            await asyncio.sleep(2)
            status = await self.get_status()
            if status['is_alive']:
                return True, "✅ Heroku userbot muvaffaqiyatli ishga tushirildi!"
            else:
                return False, "⚠️ Jarayon boshlandi, lekin screen topilmadi."
        return False, f"❌ Xato: {err}"

    async def stop(self) -> Tuple[bool, str]:
        """Heroku userbotni to'xtatish"""
        _, _, code = await self.ssh.run(
            f"screen -S {self.screen_name} -X quit"
        )
        # Python jarayonini ham o'ldirish
        await self.ssh.run(
            "pkill -f 'python.*heroku' 2>/dev/null || true"
        )
        if code == 0:
            return True, "✅ Heroku userbot to'xtatildi."
        return False, "⚠️ Screen sessiya topilmadi, lekin jarayon o'ldirildi."

    async def restart(self) -> Tuple[bool, str]:
        """Heroku userbotni qayta ishga tushirish"""
        await self.stop()
        await asyncio.sleep(3)
        return await self.start()

    async def update(self) -> Tuple[bool, str]:
        """GitHub dan yangi versiyani olish"""
        cmd = (
            f"cd {self.heroku_path} && "
            "git fetch origin && git reset --hard origin/master"
        )
        out, err, code = await self.ssh.run(cmd, timeout=60)
        if code == 0:
            return True, f"✅ Yangilandi!\n<code>{out[-500:] if out else 'OK'}</code>"
        return False, f"❌ Yangilashda xato:\n<code>{err[-500:]}</code>"

    async def get_logs(self, lines: int = 30) -> str:
        """So'nggi loglarni olish"""
        # Screen logidan o'qish
        out, err, code = await self.ssh.run(
            f"cd {self.heroku_path} && "
            f"tail -n {lines} heroku.log 2>/dev/null || "
            f"journalctl -u heroku -n {lines} 2>/dev/null || "
            f"echo 'Log fayl topilmadi'"
        )
        return out or err or "Log yo'q"

    async def install_module(self, module_url: str) -> Tuple[bool, str]:
        """Modul yuklab o'rnatish"""
        # Screen ga buyruq yuborish (userbot ichida .dlmod)
        # Bu usul: screen ga tuning buyruq yozish
        # Lekin bu ishlamaydi, chunki userbot Telegram da ishlaydi
        # Shuning uchun to'g'ridan pip bilan yuklaymiz
        import urllib.parse
        module_name = module_url.split("/")[-1]
        cmd = (
            f"cd {self.heroku_path} && "
            f"wget -q '{module_url}' -O modules/{module_name} && "
            f"echo 'OK'"
        )
        out, err, code = await self.ssh.run(cmd, timeout=30)
        if code == 0 and "OK" in out:
            return True, f"✅ Modul yuklab olindi: <code>{module_name}</code>"
        return False, f"❌ Xato: {err}"

    async def get_system_info(self) -> str:
        """Server haqida to'liq ma'lumot"""
        cmds = {
            "os": "cat /etc/os-release | grep PRETTY_NAME | cut -d'=' -f2 | tr -d '\"'",
            "cpu_model": "cat /proc/cpuinfo | grep 'model name' | head -1 | cut -d':' -f2",
            "cpu_cores": "nproc",
            "ram_total": "free -h | grep Mem | awk '{print $2}'",
            "ram_used": "free -h | grep Mem | awk '{print $3}'",
            "disk_total": "df -h / | tail -1 | awk '{print $2}'",
            "disk_used": "df -h / | tail -1 | awk '{print $3}'",
            "ip": "curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}'",
        }

        results = {}
        for key, cmd in cmds.items():
            out, _, _ = await self.ssh.run(cmd)
            results[key] = out.strip()

        return (
            f"🖥️ <b>Server Ma'lumotlari</b>\n\n"
            f"📌 <b>OS:</b> {results.get('os', 'N/A')}\n"
            f"⚙️ <b>CPU:</b> {results.get('cpu_model', 'N/A').strip()} "
            f"({results.get('cpu_cores', '?')} yadroli)\n"
            f"💾 <b>RAM:</b> {results.get('ram_used', '?')} / {results.get('ram_total', '?')}\n"
            f"💿 <b>Disk:</b> {results.get('disk_used', '?')} / {results.get('disk_total', '?')}\n"
            f"🌐 <b>IP:</b> <code>{results.get('ip', 'N/A')}</code>"
        )

    async def run_custom_command(self, command: str) -> Tuple[str, bool]:
        """Maxsus buyruq bajarish (faqat adminlar uchun)"""
        # Xavfli buyruqlarni bloklash
        BLOCKED = ["rm -rf /", "mkfs", "> /dev/sda", "dd if=/dev/zero",
                   ":(){ :|:& };:", "fork bomb"]
        for blocked in BLOCKED:
            if blocked in command.lower():
                return "❌ Bu buyruq bloklangan!", False

        out, err, code = await self.ssh.run(command, timeout=30)
        result = out or err or "(natija yo'q)"
        return result[-2000:], code == 0  # Telegram xabar limiti


# ===== FOYDALANUVCHI SSH MA'LUMOTLARINI SAQLASH =====

import json
import aiosqlite

SSH_DB = "data/ssh_credentials.db"


async def init_ssh_db():
    """SSH ma'lumotlar bazasini yaratish"""
    import os
    os.makedirs("data", exist_ok=True)
    async with aiosqlite.connect(SSH_DB) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS ssh_credentials (
                user_id INTEGER PRIMARY KEY,
                host TEXT NOT NULL,
                port INTEGER DEFAULT 22,
                username TEXT NOT NULL,
                password TEXT,
                screen_name TEXT DEFAULT 'heroku',
                heroku_path TEXT DEFAULT '~/Heroku',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.commit()


async def save_ssh_creds(user_id: int, host: str, port: int,
                          username: str, password: str,
                          screen_name: str = "heroku",
                          heroku_path: str = "~/Heroku"):
    async with aiosqlite.connect(SSH_DB) as db:
        await db.execute("""
            INSERT INTO ssh_credentials
                (user_id, host, port, username, password, screen_name, heroku_path)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                host=excluded.host, port=excluded.port,
                username=excluded.username, password=excluded.password,
                screen_name=excluded.screen_name, heroku_path=excluded.heroku_path
        """, (user_id, host, port, username, password, screen_name, heroku_path))
        await db.commit()


async def get_ssh_creds(user_id: int):
    async with aiosqlite.connect(SSH_DB) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM ssh_credentials WHERE user_id = ?", (user_id,)
        ) as cur:
            return await cur.fetchone()


async def delete_ssh_creds(user_id: int):
    async with aiosqlite.connect(SSH_DB) as db:
        await db.execute(
            "DELETE FROM ssh_credentials WHERE user_id = ?", (user_id,)
        )
        await db.commit()


async def get_ssh_controller(user_id: int) -> Optional[HerokuSSHController]:
    """Foydalanuvchi uchun SSH controller yaratish"""
    creds = await get_ssh_creds(user_id)
    if not creds:
        return None

    ssh = SSHManager(
        host=creds['host'],
        port=creds['port'],
        username=creds['username'],
        password=creds['password'],
    )
    return HerokuSSHController(
        ssh=ssh,
        screen_name=creds['screen_name'],
        heroku_path=creds['heroku_path']
    )
