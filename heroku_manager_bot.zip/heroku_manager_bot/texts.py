"""
🇺🇿 O'zbek tilidagi barcha matnlar
"""

# ========== ASOSIY ==========
WELCOME = """
🪐 <b>Heroku Manager Botga xush kelibsiz!</b>

Bu bot orqali siz:
✅ <b>Heroku Userbot</b>ni o'rnatishingiz
⚙️ Userbotingizni sozlashingiz
📚 Qo'llanmalarni o'qishingiz
💎 Premium obuna olishingiz mumkin

Boshlash uchun quyidagi tugmalardan foydalaning 👇
"""

MAIN_MENU = "🏠 <b>Asosiy menyu</b>\n\nNimadan boshlashni xohlaysiz?"

BACK = "🔙 Orqaga"
CANCEL = "❌ Bekor qilish"
CLOSE = "❌ Yopish"
CONFIRM = "✅ Tasdiqlash"

# ========== RO'YXATDAN O'TISH ==========
REGISTER_SUCCESS = """
✅ <b>Ro'yxatdan muvaffaqiyatli o'tdingiz!</b>

Endi siz Heroku Manager Botdan to'liq foydalanishingiz mumkin.
"""

ALREADY_REGISTERED = "ℹ️ Siz allaqachon ro'yxatdan o'tgansiz."

BANNED = "🚫 <b>Siz bloklangansiz.</b>\nAdministratorga murojaat qiling."

# ========== O'RNATISH ==========
INSTALL_INTRO = """
⚙️ <b>Heroku Userbot O'rnatish</b>

Ushbu qo'llanma sizga Heroku Userbotni o'rnatishda yordam beradi.

📋 <b>Kerakli narsalar:</b>
• VPS/VDS server (Linux)
• Telegram API kredensiallari
• Python 3.9+

Qaysi server turini ishlatmoqchisiz?
"""

INSTALL_SELECT_SERVER = "🖥️ <b>Server turini tanlang:</b>"

INSTALL_VPS_GUIDE = """
🖥️ <b>VPS/VDS Server uchun O'rnatish</b>

<b>1-qadam: Serverga ulaning</b>
<code>ssh root@YOUR_SERVER_IP</code>

<b>2-qadam: Kerakli paketlarni o'rnating</b>
<code>apt update && apt install git python3 python3-pip -y</code>

<b>3-qadam: Heroku Userbotni yuklab oling</b>
<code>git clone https://github.com/coddrago/Heroku
cd Heroku</code>

<b>4-qadam: Kutubxonalarni o'rnating</b>
<code>pip install -r requirements.txt</code>

<b>5-qadam: Botni ishga tushiring</b>
<code>python3 -m heroku</code>

💡 <b>Root foydalanuvchi uchun:</b>
<code>python3 -m heroku --root</code>

💡 <b>Fon rejimida ishlatish uchun:</b>
<code>screen -S heroku
python3 -m heroku
# CTRL+A, keyin D bosing</code>
"""

INSTALL_DOCKER_GUIDE = """
🐳 <b>Docker orqali O'rnatish</b>

<b>1-qadam: Docker o'rnating</b>
<code>curl -fsSL https://get.docker.com | sh</code>

<b>2-qadam: Heroku Userbotni yuklab oling</b>
<code>git clone https://github.com/coddrago/Heroku
cd Heroku</code>

<b>3-qadam: Docker image yarating</b>
<code>docker build -t heroku-userbot .</code>

<b>4-qadam: Konteyner ishga tushiring</b>
<code>docker run -d --name heroku \\
  -p 8080:8080 \\
  -v ./data:/data \\
  heroku-userbot</code>

<b>5-qadam: Loglarni kuzating</b>
<code>docker logs -f heroku</code>

🌐 Keyin brauzerda: <code>http://YOUR_IP:8080</code>
"""

INSTALL_HIKKAHOST_GUIDE = """
🌐 <b>HikkaHost/JamHost uchun O'rnatish</b>

HikkaHost va JamHost — Heroku Userbotni bepul/arzon hosting xizmatlari.

<b>HikkaHost:</b>
1. @HikkaHostBot ga yozing
2. /start buyrug'ini yuboring
3. Ko'rsatmalarga amal qiling

<b>JamHost:</b>
1. @JamHostBot ga yozing  
2. /start buyrug'ini yuboring
3. Heroku versiyasini tanlang

✅ Bu hostinglar Heroku bilan to'liq mos keladi!
"""

INSTALL_API_INFO = """
🔑 <b>Telegram API Kredensiallarini Olish</b>

<b>1-qadam:</b> my.telegram.org saytiga kiring

<b>2-qadam:</b> Telefon raqamingiz bilan kiring

<b>3-qadam:</b> "API Development Tools" bo'limiga o'ting

<b>4-qadam:</b> Yangi ilova yarating:
• App title: istalgan nom
• Short name: istalgan qisqa nom
• Platform: Desktop

<b>5-qadam:</b> Quyidagilarni saqlang:
• <code>api_id</code> (raqam)
• <code>api_hash</code> (uzun matn)

⚠️ <b>Bu ma'lumotlarni hech kimga bermang!</b>
"""

SETUP_REQUEST_API = """
⚙️ <b>Heroku Sozlash Yordami</b>

Siz Heroku Userbotingizni sozlashda yordam so'rmoqchisiz.

Iltimos, quyidagi ma'lumotlarni kiriting:

<b>API ID raqamingiz:</b> (faqat raqam, masalan: 12345678)
"""

SETUP_REQUEST_HASH = "✅ API ID qabul qilindi!\n\n<b>API Hash:</b> (32 belgili matn)"

SETUP_REQUEST_SERVER = """
✅ API kredensiallari qabul qilindi!

<b>Server turini tanlang:</b>
"""

SETUP_SAVED = """
✅ <b>Ma'lumotlar saqlandi!</b>

Sizning so'rovingiz administratorga yuborildi.
Tez orada siz bilan bog'lanamiz.

📋 <b>Keyingi qadamlar:</b>
1. Administrator siz bilan bog'lanadi
2. O'rnatish jarayonida yordam beriladi
3. Savollar uchun /support buyrug'ini yuboring
"""

# ========== QOLLANMA ==========
GUIDE_MENU = """
📚 <b>Qo'llanmalar va Yordam</b>

Quyidagi mavzulardan birini tanlang:
"""

GUIDE_COMMANDS = """
📋 <b>Asosiy Buyruqlar</b>

<b>Umumiy:</b>
• <code>.help</code> — barcha modullar ro'yxati
• <code>.ping</code> — bot ishlayaptimi tekshirish
• <code>.info</code> — bot haqida ma'lumot
• <code>.update</code> — botni yangilash

<b>Modullar:</b>
• <code>.dlmod [url]</code> — modul yuklab olish
• <code>.loadmod</code> — modul yuklash
• <code>.unloadmod [nom]</code> — modulni o'chirish
• <code>.mods</code> — yuklangan modullar

<b>Sozlamalar:</b>
• <code>.cfg</code> — konfiguratsiya
• <code>.settings</code> — sozlamalar
• <code>.prefix [belgi]</code> — prefiks o'zgartirish

<b>Xavfsizlik:</b>
• <code>.security</code> — xavfsizlik sozlamalari
• <code>.api_fw_protection</code> — API himoya

<b>Ma'lumotlar bazasi:</b>
• <code>.backup</code> — zaxira nusxa
• <code>.restore</code> — nusxadan tiklash
"""

GUIDE_MODULES = """
🧩 <b>Modullar Haqida</b>

<b>Modul nima?</b>
Modul — bu Heroku Userbotga yangi funksiyalar qo'shadigan kichik dastur.

<b>Modul yuklab olish:</b>
<code>.dlmod https://example.com/module.py</code>

<b>Ishonchli modul manbalari:</b>
• @HerokuMods — rasmiy modullar
• @HikaModules — Hikka modullari (mos keladi)

<b>Modul o'rnatish:</b>
1. Modul faylini yuklab oling (.py)
2. <code>.loadmod</code> buyrug'ini yuboring
3. Faylni xabarga ilova qiling

⚠️ <b>Noma'lum manbalardan modul o'rnatmang!</b>
"""

GUIDE_SECURITY = """
🔒 <b>Xavfsizlik Sozlamalari</b>

<b>Muhim himoya qadamlari:</b>

1️⃣ <b>API himoyasini yoqing:</b>
<code>.api_fw_protection</code>

2️⃣ <b>Sudo foydalanuvchilarni cheklang:</b>
<code>.security</code> → Owners sozlamalari

3️⃣ <b>Xavfli buyruqlardan saqlaning:</b>
• <code>.eval</code> — faqat o'zingiz uchun
• <code>.terminal</code> — faqat o'zingiz uchun
• <code>.ecpp</code> — faqat o'zingiz uchun

4️⃣ <b>Zaxira nusxa saqlang:</b>
<code>.backup</code> — har kuni ishlatish tavsiya etiladi

5️⃣ <b>Session faylini saqlang:</b>
<code>heroku-XXXXXX.session</code> faylini xavfsiz joyda saqlang
"""

GUIDE_TROUBLESHOOT = """
🔧 <b>Muammolar va Yechimlar</b>

<b>❌ Bot ishlamayapti:</b>
<code>python3 -m heroku</code> qayta ishga tushiring

<b>❌ FloodWait xatosi:</b>
Bir necha daqiqa kuting, keyin qayta urinib ko'ring

<b>❌ Session muammo:</b>
<code>heroku-*.session</code> faylini o'chirib, qayta kiring

<b>❌ Modul yuklanmayapti:</b>
• Modul versiyasini tekshiring
• <code>.logs</code> buyrug'i bilan xatoni ko'ring

<b>❌ API xatosi:</b>
API ID va API Hash to'g'riligini tekshiring

<b>❌ Internet muammo:</b>
Server internet ulanishini tekshiring

Muammo yechilmasa → /support buyrug'i orqali yordam so'rang
"""

# ========== OBUNA ==========
SUBSCRIPTION_INFO = """
💎 <b>Premium Obuna</b>

Heroku Manager Bot orqali premium obuna oling va qo'shimcha imkoniyatlardan foydalaning!

<b>🆓 Bepul:</b>
• O'rnatish qo'llanmalari
• Asosiy yordam
• Buyruqlar ro'yxati

<b>💫 Premium (1 oy):</b>
• ✅ Barcha bepul imkoniyatlar
• ✅ Shaxsiy o'rnatish yordami
• ✅ 7/24 texnik yordam
• ✅ Modullar to'plami
• ✅ Tezkor javob
• 💰 <b>30,000 so'm</b>

<b>👑 VIP (3 oy):</b>
• ✅ Barcha Premium imkoniyatlar
• ✅ Server sozlash xizmati
• ✅ Shaxsiy bot sozlash
• ✅ Ustuvor support
• 💰 <b>75,000 so'm</b>

To'lov uchun kerakli tarifni tanlang 👇
"""

PAYMENT_SELECT_PLAN = "💳 <b>Tarif rejasini tanlang:</b>"

PAYMENT_INSTRUCTION = """
💳 <b>To'lov Yo'riqnomasi</b>

<b>Tanlangan tarif:</b> {plan}
<b>Summa:</b> {amount} so'm

<b>To'lov usullari:</b>

🏦 <b>Karta orqali (Uzcard/Humo):</b>
<code>{card_number}</code>
Karta egasi: {card_owner}

📱 <b>Payme/Click:</b>
Telefon: <code>{phone}</code>

<b>To'lovdan keyin:</b>
1. To'lov chekini (screenshot) yuboring
2. Yoki to'lov ID raqamini yuboring
3. Administrator 10-30 daqiqa ichida tasdiqlaydi

⚠️ <b>Izoh qatoriga Telegram ID raqamingizni yozing:</b>
<code>{user_id}</code>
"""

PAYMENT_SENT = """
✅ <b>To'lov ma'lumotlari qabul qilindi!</b>

📋 <b>So'rov raqami:</b> #{payment_id}

Administrator to'lovingizni tekshirib, tez orada obunangizni faollashtiradi.
Odatda 10-30 daqiqa ichida.

❓ Savol bo'lsa: /support
"""

PAYMENT_APPROVED = """
🎉 <b>To'lovingiz tasdiqlandi!</b>

✅ <b>{plan}</b> obunangiz faollashtirildi!
📅 Amal qilish muddati: <b>{expires}</b>

Endi barcha premium imkoniyatlardan foydalanishingiz mumkin.
Savollar uchun: /support
"""

PAYMENT_REJECTED = """
❌ <b>To'lovingiz rad etildi.</b>

Sabab: {reason}

Muammo bo'lsa, /support orqali murojaat qiling.
"""

SUBSCRIPTION_ACTIVE = """
✅ <b>Sizning obunangiz faol</b>

📦 <b>Tarif:</b> {plan}
📅 <b>Tugash sanasi:</b> {expires}

Barcha premium imkoniyatlardan foydalanishingiz mumkin!
"""

SUBSCRIPTION_EXPIRED = """
⏰ <b>Obunangiz muddati tugagan</b>

Davom ettirish uchun obuna yangilashtiring 👇
"""

NO_SUBSCRIPTION = """
💡 <b>Sizda obuna yo'q</b>

Premium imkoniyatlardan foydalanish uchun obuna oling 👇
"""

# ========== SUPPORT ==========
SUPPORT_MENU = """
💬 <b>Qo'llab-Quvvatlash</b>

Muammoingizni yozing va administrator imkon qadar tez javob beradi.

📌 <b>Tezkor javob uchun:</b>
• Muammoni batafsil tavsiflang
• Xato xabarini yuboring
• Server turini bildiring
"""

TICKET_CREATED = """
✅ <b>Murojaat yuborildi!</b>

📋 <b>Ticket raqami:</b> #{ticket_id}

Administrator tez orada javob beradi.
"""

TICKET_REPLY = """
📬 <b>Murojaatingizga javob:</b>

<i>{reply}</i>

Yana savol bo'lsa /support yuboring.
"""

PREMIUM_ONLY = """
🔒 <b>Bu funksiya faqat Premium foydalanuvchilar uchun</b>

Premium obuna olish uchun /subscription buyrug'ini yuboring.
"""

# ========== ADMIN ==========
ADMIN_PANEL = """
👑 <b>Admin Panel</b>

Boshqaruv tizimiga xush kelibsiz.
"""

ADMIN_STATS = """
📊 <b>Bot Statistikasi</b>

👥 <b>Foydalanuvchilar:</b> {total_users}
✅ <b>Faol:</b> {active_users}
💎 <b>Premium:</b> {premium_users}

💰 <b>To'lovlar:</b> {total_payments} ta
💵 <b>Jami daromad:</b> {total_revenue:,} so'm

🎫 <b>Ochiq ticketlar:</b> {open_tickets}
"""

ADMIN_BROADCAST_REQUEST = """
📢 <b>Xabar Yuborish</b>

Barcha foydalanuvchilarga yubormoqchi bo'lgan xabaringizni yozing:
"""

ADMIN_BROADCAST_CONFIRM = """
📢 <b>Xabarni tasdiqlang:</b>

{message}

<b>Yuborish uchun ✅ Tasdiqlash tugmasini bosing</b>
"""

ADMIN_BROADCAST_SENT = "✅ Xabar {count} ta foydalanuvchiga yuborildi."

ADMIN_USER_NOT_FOUND = "❌ Foydalanuvchi topilmadi."

ADMIN_PAYMENT_NOTIFY_ADMIN = """
💳 <b>Yangi To'lov So'rovi!</b>

👤 <b>Foydalanuvchi:</b> {name} (@{username})
🆔 <b>ID:</b> <code>{user_id}</code>
📦 <b>Tarif:</b> {plan}
💰 <b>Summa:</b> {amount:,} so'm
🔢 <b>So'rov #:</b> {payment_id}
"""

ADMIN_NEW_TICKET = """
🎫 <b>Yangi Murojaat!</b>

👤 <b>Foydalanuvchi:</b> {name} (@{username})
🆔 <b>ID:</b> <code>{user_id}</code>
🔢 <b>Ticket #:</b> {ticket_id}

📝 <b>Xabar:</b>
{message}
"""

ADMIN_NEW_SETUP = """
⚙️ <b>Yangi Sozlash So'rovi!</b>

👤 <b>Foydalanuvchi:</b> {name} (@{username})
🆔 <b>ID:</b> <code>{user_id}</code>
🖥️ <b>Server turi:</b> {server_type}
"""

USER_BANNED = "✅ Foydalanuvchi bloklandi."
USER_UNBANNED = "✅ Foydalanuvchi blokdan chiqarildi."
USER_PROMOTED = "✅ Foydalanuvchi admin qilindi."
