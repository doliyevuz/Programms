"""
Ma'lumotlar bazasi - SQLite
"""

import aiosqlite
import os
import logging
from datetime import datetime

DB_PATH = "data/heroku_bot.db"
logger = logging.getLogger(__name__)


async def init_db():
    os.makedirs("data", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                user_id INTEGER UNIQUE NOT NULL,
                username TEXT,
                full_name TEXT,
                phone TEXT,
                is_banned INTEGER DEFAULT 0,
                is_admin INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY,
                user_id INTEGER UNIQUE NOT NULL,
                plan TEXT DEFAULT 'free',
                expires_at TEXT,
                is_active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );

            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                plan TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                payment_id TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );

            CREATE TABLE IF NOT EXISTS installations (
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL,
                server_type TEXT,
                api_id TEXT,
                api_hash TEXT,
                status TEXT DEFAULT 'pending',
                notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );

            CREATE TABLE IF NOT EXISTS support_tickets (
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL,
                message TEXT NOT NULL,
                status TEXT DEFAULT 'open',
                reply TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );
        """)
        await db.commit()
    logger.info("✅ Ma'lumotlar bazasi tayyor")


# ========== USER FUNCTIONS ==========

async def get_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ) as cursor:
            return await cursor.fetchone()


async def create_user(user_id: int, username: str, full_name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT OR IGNORE INTO users (user_id, username, full_name)
               VALUES (?, ?, ?)""",
            (user_id, username, full_name)
        )
        await db.commit()


async def get_all_users():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users ORDER BY created_at DESC") as cursor:
            return await cursor.fetchall()


async def ban_user(user_id: int, ban: bool = True):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET is_banned = ? WHERE user_id = ?",
            (1 if ban else 0, user_id)
        )
        await db.commit()


async def set_admin(user_id: int, is_admin: bool = True):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET is_admin = ? WHERE user_id = ?",
            (1 if is_admin else 0, user_id)
        )
        await db.commit()


async def get_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        stats = {}
        async with db.execute("SELECT COUNT(*) as c FROM users") as cur:
            stats['total_users'] = (await cur.fetchone())['c']
        async with db.execute("SELECT COUNT(*) as c FROM users WHERE is_banned = 0") as cur:
            stats['active_users'] = (await cur.fetchone())['c']
        async with db.execute(
            "SELECT COUNT(*) as c FROM subscriptions WHERE is_active = 1 AND plan != 'free'"
        ) as cur:
            stats['premium_users'] = (await cur.fetchone())['c']
        async with db.execute(
            "SELECT COUNT(*) as c FROM payments WHERE status = 'approved'"
        ) as cur:
            stats['total_payments'] = (await cur.fetchone())['c']
        async with db.execute(
            "SELECT COALESCE(SUM(amount), 0) as s FROM payments WHERE status = 'approved'"
        ) as cur:
            stats['total_revenue'] = (await cur.fetchone())['s']
        async with db.execute(
            "SELECT COUNT(*) as c FROM support_tickets WHERE status = 'open'"
        ) as cur:
            stats['open_tickets'] = (await cur.fetchone())['c']
        return stats


# ========== SUBSCRIPTION FUNCTIONS ==========

async def get_subscription(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM subscriptions WHERE user_id = ?", (user_id,)
        ) as cursor:
            return await cursor.fetchone()


async def create_or_update_subscription(user_id: int, plan: str, expires_at: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO subscriptions (user_id, plan, expires_at, is_active)
               VALUES (?, ?, ?, 1)
               ON CONFLICT(user_id) DO UPDATE SET
               plan = excluded.plan,
               expires_at = excluded.expires_at,
               is_active = 1""",
            (user_id, plan, expires_at)
        )
        await db.commit()


async def is_premium(user_id: int) -> bool:
    sub = await get_subscription(user_id)
    if not sub:
        return False
    if sub['plan'] == 'free':
        return False
    if sub['expires_at']:
        from datetime import datetime
        exp = datetime.fromisoformat(sub['expires_at'])
        if exp < datetime.now():
            return False
    return sub['is_active'] == 1


# ========== PAYMENT FUNCTIONS ==========

async def create_payment(user_id: int, amount: float, plan: str, payment_id: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """INSERT INTO payments (user_id, amount, plan, payment_id)
               VALUES (?, ?, ?, ?)""",
            (user_id, amount, plan, payment_id)
        ) as cursor:
            return cursor.lastrowid


async def update_payment_status(payment_id_row: int, status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE payments SET status = ? WHERE id = ?",
            (status, payment_id_row)
        )
        await db.commit()


async def get_pending_payments():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """SELECT p.*, u.username, u.full_name 
               FROM payments p JOIN users u ON p.user_id = u.user_id
               WHERE p.status = 'pending'
               ORDER BY p.created_at DESC"""
        ) as cursor:
            return await cursor.fetchall()


async def get_payment(payment_row_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM payments WHERE id = ?", (payment_row_id,)
        ) as cursor:
            return await cursor.fetchone()


# ========== INSTALLATION FUNCTIONS ==========

async def create_installation(user_id: int, server_type: str):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "INSERT INTO installations (user_id, server_type) VALUES (?, ?)",
            (user_id, server_type)
        ) as cursor:
            return cursor.lastrowid


async def update_installation(install_id: int, **kwargs):
    if not kwargs:
        return
    fields = ", ".join(f"{k} = ?" for k in kwargs)
    values = list(kwargs.values()) + [install_id]
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            f"UPDATE installations SET {fields} WHERE id = ?", values
        )
        await db.commit()


async def get_user_installations(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM installations WHERE user_id = ? ORDER BY created_at DESC",
            (user_id,)
        ) as cursor:
            return await cursor.fetchall()


# ========== TICKET FUNCTIONS ==========

async def create_ticket(user_id: int, message: str):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "INSERT INTO support_tickets (user_id, message) VALUES (?, ?)",
            (user_id, message)
        ) as cursor:
            return cursor.lastrowid


async def get_open_tickets():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """SELECT t.*, u.username, u.full_name 
               FROM support_tickets t JOIN users u ON t.user_id = u.user_id
               WHERE t.status = 'open'
               ORDER BY t.created_at ASC"""
        ) as cursor:
            return await cursor.fetchall()


async def reply_ticket(ticket_id: int, reply: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE support_tickets SET status = 'closed', reply = ? WHERE id = ?",
            (reply, ticket_id)
        )
        await db.commit()
